package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private TextView resultView;
 public void convertDollertoTaka(View view){
     Log.i("Info", "Button pressed");
     EditText editTextNumberDecimal = (EditText) findViewById(R.id.editTextNumberDecimal);
     resultView =(TextView) findViewById(R.id.restext);
     String amountDoller = editTextNumberDecimal.getText().toString();
     double amountDollerinDouble = Double.parseDouble(amountDoller);
     double amountInTaka = amountDollerinDouble * 84.11;
     String amountInTakaString = String.format("%.2f",amountInTaka);
     resultView.setText("$"+amountDoller+" is "+amountInTakaString+" Taka");
//     Toast.makeText(this, "$"+amountDoller+" is "+amountInTakaString+" Taka", Toast.LENGTH_LONG).show();


 }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}